				///***\\\ Implementation of game Doodle jump using openGl///***\\\

The main.cpp file includes the code for the implemetaion of the doodle jump game in cpp using openGl libraries. The aim of the player is to score as much as possible. The score increases as the height of the doodle increases.

To play and enjoy the game just start main.exe and follow the instructions.

Aim of the game is to score as high as possible. Use keyboard to move the ball horizontally and use the stairs to go up.Score is dependent on the height you travel.

***CONTROLS:- Use Keyboard key 'a' to move ball left and 'd' to move the ball right.

***Note: You should have openGl libraries installed and attached to your your compiler to run the code. 
Preffered Compiler: Codeblocks